python server.py
